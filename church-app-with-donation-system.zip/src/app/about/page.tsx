import { DonateButton } from "@/components/DonateButton";

export const metadata = {
  title: "About Us | TRUE Worshippers Evangelical Assembly International",
  description:
    "Learn about the vision, mission, and values of TRUE Worshippers Evangelical Assembly International.",
};

export default function AboutPage() {
  return (
    <>
      <section className="bg-indigo-950 py-24 text-center text-white">
        <div className="mx-auto max-w-4xl px-6">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-amber-400">
            Who We Are
          </p>
          <h1 className="mt-4 text-4xl font-bold md:text-5xl">About Us</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-indigo-100">
            TRUE Worshippers Evangelical Assembly International is a
            Christ-centered, Bible-believing church committed to worshipping God
            in spirit and in truth.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid gap-12 md:grid-cols-2">
          <div>
            <h2 className="text-2xl font-bold text-indigo-950">Our Vision</h2>
            <p className="mt-4 leading-relaxed text-slate-600">
              To raise a global company of true worshippers who live in holiness,
              demonstrate the love of Christ, and transform their communities
              through the power of the Gospel.
            </p>
          </div>
          <div>
            <h2 className="text-2xl font-bold text-indigo-950">Our Mission</h2>
            <p className="mt-4 leading-relaxed text-slate-600">
              To preach the undiluted Word of God, build believers through
              discipleship, empower families, and send missionaries to the ends
              of the earth.
            </p>
          </div>
        </div>

        <div className="mt-16 rounded-3xl bg-indigo-50 p-8 md:p-12">
          <h2 className="text-2xl font-bold text-indigo-950">Our Core Values</h2>
          <ul className="mt-6 grid gap-4 sm:grid-cols-2">
            {[
              "True Worship in Spirit and Truth",
              "Excellence in Service",
              "Love and Unity",
              "Integrity and Accountability",
              "Evangelism and Missions",
              "Family and Community Care",
            ].map((value) => (
              <li key={value} className="flex items-start gap-3 text-slate-700">
                <span className="mt-1.5 h-2 w-2 shrink-0 rounded-full bg-amber-500" />
                {value}
              </li>
            ))}
          </ul>
        </div>

        <div className="mt-16 text-center">
          <h2 className="text-2xl font-bold text-indigo-950">
            Be Part of Our Story
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-slate-600">
            Your support helps us reach more lives, plant churches, and extend
            the love of Christ to every nation.
          </p>
          <div className="mt-8">
            <DonateButton />
          </div>
        </div>
      </section>
    </>
  );
}
