import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { verifySession } from "@/lib/auth";
import { logout } from "@/lib/actions";

export const metadata = {
  title: "Admin Dashboard | TRUE Worshippers Evangelical Assembly International",
  description: "Administrative dashboard for the church website.",
};

export default async function AdminDashboardPage() {
  const cookieStore = await cookies();
  const token = cookieStore.get("session")?.value;

  if (!token) {
    redirect("/admin/login");
  }

  let session: { username: string; role: string };
  try {
    session = await verifySession(token);
  } catch {
    redirect("/admin/login");
  }

  return (
    <section className="min-h-[80vh] bg-slate-50 px-6 py-12">
      <div className="mx-auto max-w-5xl">
        <div className="rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-100">
          <div className="flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-center">
            <div>
              <h1 className="text-2xl font-bold text-indigo-950">
                Admin Dashboard
              </h1>
              <p className="mt-1 text-slate-600">
                Welcome back, {session.username} ({session.role}).
              </p>
            </div>
            <form action={logout}>
              <button
                type="submit"
                className="rounded-xl bg-red-600 px-5 py-2.5 font-semibold text-white transition hover:bg-red-700"
              >
                Logout
              </button>
            </form>
          </div>

          <div className="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <div className="rounded-2xl bg-indigo-50 p-6">
              <h3 className="font-bold text-indigo-950">Website Sections</h3>
              <ul className="mt-3 space-y-2 text-sm text-slate-600">
                <li>Homepage hero and announcements</li>
                <li>About the ministry</li>
                <li>Pastors profiles</li>
                <li>Donation page</li>
              </ul>
            </div>
            <div className="rounded-2xl bg-indigo-50 p-6">
              <h3 className="font-bold text-indigo-950">Giving Link</h3>
              <p className="mt-3 text-sm text-slate-600">
                Flutterwave donation page is configured at:
              </p>
              <a
                href="https://flutterwave.com/donate/l6hwq0gpjibb"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-2 inline-block break-all text-sm font-medium text-indigo-700 hover:underline"
              >
                flutterwave.com/donate/l6hwq0gpjibb
              </a>
            </div>
            <div className="rounded-2xl bg-indigo-50 p-6">
              <h3 className="font-bold text-indigo-950">Security</h3>
              <p className="mt-3 text-sm text-slate-600">
                Keep your admin password safe. Sessions expire after 8 hours of
                inactivity.
              </p>
            </div>
          </div>

          <div className="mt-10 rounded-2xl border border-slate-200 p-6">
            <h3 className="font-bold text-indigo-950">Quick Actions</h3>
            <div className="mt-4 flex flex-wrap gap-3">
              <a
                href="https://flutterwave.com/donate/l6hwq0gpjibb"
                target="_blank"
                rel="noopener noreferrer"
                className="rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-semibold text-indigo-950 transition hover:bg-amber-400"
              >
                View Donation Page
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
