import { LoginForm } from "./LoginForm";

export const metadata = {
  title: "Admin Login | TRUE Worshippers Evangelical Assembly International",
  description: "Administrative login for TRUE Worshippers Evangelical Assembly International.",
};

export default function AdminLoginPage() {
  return (
    <section className="flex min-h-[80vh] items-center justify-center bg-slate-50 px-6 py-12">
      <div className="w-full max-w-md rounded-3xl bg-white p-8 shadow-xl ring-1 ring-slate-100">
        <h1 className="text-center text-2xl font-bold text-indigo-950">
          Admin Login
        </h1>
        <p className="mt-2 text-center text-sm text-slate-600">
          TRUE Worshippers Evangelical Assembly International
        </p>
        <LoginForm />
      </div>
    </section>
  );
}
