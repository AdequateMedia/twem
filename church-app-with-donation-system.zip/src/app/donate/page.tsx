import { DonateButton } from "@/components/DonateButton";

export const metadata = {
  title: "Donate | TRUE Worshippers Evangelical Assembly International",
  description:
    "Give securely online to TRUE Worshippers Evangelical Assembly International through Flutterwave.",
};

export default function DonatePage() {
  return (
    <>
      <section className="bg-indigo-950 py-24 text-center text-white">
        <div className="mx-auto max-w-4xl px-6">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-amber-400">
            Give With Joy
          </p>
          <h1 className="mt-4 text-4xl font-bold md:text-5xl">Donate</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-indigo-100">
            Your generous donation helps us advance the Gospel, support our
            community, and build the Kingdom of God across the nations.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-6 py-20 text-center">
        <h2 className="text-2xl font-bold text-indigo-950">
          Secure Online Giving
        </h2>
        <p className="mt-4 text-lg text-slate-600">
          Click the button below to give safely through Flutterwave. You can use
          your card, bank transfer, mobile money, or other available payment
          methods.
        </p>

        <div className="mt-10">
          <DonateButton>
            Give Online with Flutterwave
          </DonateButton>
        </div>

        <div className="mt-16 grid gap-6 text-left sm:grid-cols-3">
          <div className="rounded-2xl bg-indigo-50 p-6">
            <h3 className="font-bold text-indigo-950">Church Growth</h3>
            <p className="mt-2 text-sm text-slate-600">
              Supporting worship services, facilities, and ministry operations.
            </p>
          </div>
          <div className="rounded-2xl bg-indigo-50 p-6">
            <h3 className="font-bold text-indigo-950">Outreach</h3>
            <p className="mt-2 text-sm text-slate-600">
              Funding evangelism, community care, and mission trips.
            </p>
          </div>
          <div className="rounded-2xl bg-indigo-50 p-6">
            <h3 className="font-bold text-indigo-950">Families</h3>
            <p className="mt-2 text-sm text-slate-600">
              Helping families, widows, and children in need.
            </p>
          </div>
        </div>

        <p className="mt-12 text-sm text-slate-500">
          Thank you for partnering with TRUE Worshippers Evangelical Assembly
          International. May the Lord bless you abundantly.
        </p>
      </section>
    </>
  );
}
