import Image from "next/image";
import Link from "next/link";
import { DonateButton } from "@/components/DonateButton";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return (
    <>
      {/* Hero */}
      <section className="relative flex min-h-[80vh] items-center justify-center overflow-hidden text-white">
        <Image
          src="/images/hero.jpg"
          alt="Church worship"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-indigo-950/80" />

        <div className="relative z-10 mx-auto max-w-4xl px-6 text-center">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-amber-400">
            Welcome to TRUE Worshippers
          </p>
          <h1 className="mt-6 text-[clamp(2.5rem,6vw,4.5rem)] font-bold leading-[1.05]">
            Evangelical Assembly International
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg leading-relaxed text-indigo-100">
            A place of worship, love, and transformation. Join us as we raise a
            generation of true worshippers and impact nations with the Gospel.
          </p>
          <div className="mt-10 flex flex-wrap items-center justify-center gap-4">
            <DonateButton />
            <Link
              href="/about"
              className="rounded-full border-2 border-white px-8 py-3.5 text-base font-semibold text-white transition hover:bg-white hover:text-indigo-950"
            >
              Learn More
            </Link>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid items-center gap-12 md:grid-cols-2">
          <div>
            <h2 className="text-3xl font-bold text-indigo-950 md:text-4xl">
              Experience the Presence of God
            </h2>
            <p className="mt-5 text-lg leading-relaxed text-slate-600">
              At TRUE Worshippers Evangelical Assembly International, we believe
              in the power of sincere worship, the authority of God&apos;s Word, and
              the transforming work of the Holy Spirit. Everyone is welcome to
              grow in faith and purpose.
            </p>
            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              <div className="rounded-2xl bg-indigo-50 p-6">
                <h3 className="font-bold text-indigo-950">Worship</h3>
                <p className="mt-2 text-sm text-slate-600">
                  Lift your voice in spirit and truth.
                </p>
              </div>
              <div className="rounded-2xl bg-indigo-50 p-6">
                <h3 className="font-bold text-indigo-950">The Word</h3>
                <p className="mt-2 text-sm text-slate-600">
                  Sound teaching that builds strong faith.
                </p>
              </div>
              <div className="rounded-2xl bg-indigo-50 p-6">
                <h3 className="font-bold text-indigo-950">Community</h3>
                <p className="mt-2 text-sm text-slate-600">
                  A loving family that supports one another.
                </p>
              </div>
              <div className="rounded-2xl bg-indigo-50 p-6">
                <h3 className="font-bold text-indigo-950">Missions</h3>
                <p className="mt-2 text-sm text-slate-600">
                  Reaching nations with the Gospel.
                </p>
              </div>
            </div>
          </div>

          <div className="relative aspect-[4/3] overflow-hidden rounded-3xl bg-indigo-100">
            <Image
              src="/images/hero.jpg"
              alt="Church gathering"
              fill
              className="object-cover"
            />
          </div>
        </div>
      </section>

      {/* Senior Pastors */}
      <section className="bg-indigo-950 py-20 text-white">
        <div className="mx-auto max-w-6xl px-6 text-center">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-amber-400">
            Meet Our Leaders
          </p>
          <h2 className="mt-4 text-3xl font-bold md:text-4xl">
            Senior Pastor &amp; Co-Pastor
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-indigo-200">
            Under the spiritual covering of Apostle Solomon Adebowale and Rev
            Mrs Deborah Adebowale, the assembly is built on faith, integrity,
            and compassion.
          </p>
          <div className="mt-12 grid gap-8 md:grid-cols-2">
            <div className="rounded-3xl bg-white/5 p-8 backdrop-blur">
              <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-amber-500 text-3xl font-bold text-indigo-950">
                SA
              </div>
              <h3 className="text-xl font-bold">Apostle Solomon Adebowale</h3>
              <p className="mt-2 text-indigo-200">Senior Pastor</p>
              <p className="mt-4 text-sm leading-relaxed text-indigo-100">
                A visionary leader and apostle called to raise true worshippers
                and equip the body of Christ for kingdom impact.
              </p>
            </div>
            <div className="rounded-3xl bg-white/5 p-8 backdrop-blur">
              <div className="mx-auto mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-amber-500 text-3xl font-bold text-indigo-950">
                DA
              </div>
              <h3 className="text-xl font-bold">Rev Mrs Deborah Adebowale</h3>
              <p className="mt-2 text-indigo-200">Co-Pastor</p>
              <p className="mt-4 text-sm leading-relaxed text-indigo-100">
                A dedicated minister of the Gospel with a heart for women,
                families, and the spiritual growth of every believer.
              </p>
            </div>
          </div>
          <Link
            href="/pastors"
            className="mt-10 inline-block rounded-full border-2 border-white px-8 py-3.5 font-semibold text-white transition hover:bg-white hover:text-indigo-950"
          >
            Read Their Stories
          </Link>
        </div>
      </section>

      {/* Donate CTA */}
      <section className="mx-auto max-w-6xl px-6 py-20 text-center">
        <h2 className="text-3xl font-bold text-indigo-950 md:text-4xl">
          Partner With Us
        </h2>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-slate-600">
          Your generous giving supports our worship services, outreach programs,
          missions, and community development initiatives.
        </p>
        <div className="mt-10">
          <DonateButton />
        </div>
        <p className="mt-4 text-xs text-slate-500">
          Secure giving powered by Flutterwave.
        </p>
      </section>
    </>
  );
}
