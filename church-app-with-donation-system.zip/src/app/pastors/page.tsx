import { DonateButton } from "@/components/DonateButton";

export const metadata = {
  title: "Our Pastors | TRUE Worshippers Evangelical Assembly International",
  description:
    "Meet Senior Pastor Apostle Solomon Adebowale and Rev Mrs Deborah Adebowale.",
};

export default function PastorsPage() {
  return (
    <>
      <section className="bg-indigo-950 py-24 text-center text-white">
        <div className="mx-auto max-w-4xl px-6">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-amber-400">
            Spiritual Covering
          </p>
          <h1 className="mt-4 text-4xl font-bold md:text-5xl">Our Pastors</h1>
          <p className="mx-auto mt-6 max-w-2xl text-lg text-indigo-100">
            TRUE Worshippers Evangelical Assembly International is led by Apostle
            Solomon Adebowale and Rev Mrs Deborah Adebowale, servants of God with
            a passion for souls and the advancement of the Kingdom.
          </p>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="grid gap-12 lg:grid-cols-2">
          <article className="rounded-3xl bg-white shadow-xl ring-1 ring-slate-100">
            <div className="flex h-32 items-center justify-center rounded-t-3xl bg-indigo-900">
              <div className="flex h-28 w-28 -mb-14 items-center justify-center rounded-full border-4 border-white bg-amber-500 text-4xl font-bold text-indigo-950 shadow-lg">
                SA
              </div>
            </div>
            <div className="px-8 pb-10 pt-16 text-center">
              <h2 className="text-2xl font-bold text-indigo-950">
                Apostle Solomon Adebowale
              </h2>
              <p className="mt-1 font-medium text-amber-600">Senior Pastor</p>
              <p className="mt-5 text-left leading-relaxed text-slate-600">
                Apostle Solomon Adebowale is the founding senior pastor of TRUE
                Worshippers Evangelical Assembly International. He is a
                prophetic voice, teacher of the Word, and apostolic leader
                commissioned to raise true worshippers across Nigeria and the
                nations.
              </p>
              <p className="mt-4 text-left leading-relaxed text-slate-600">
                Through his ministry, many have experienced healing, deliverance,
                and a deeper walk with God. His teaching emphasizes holiness,
                prayer, worship, and the manifestation of God&apos;s power in the
                believer&apos;s daily life.
              </p>
            </div>
          </article>

          <article className="rounded-3xl bg-white shadow-xl ring-1 ring-slate-100">
            <div className="flex h-32 items-center justify-center rounded-t-3xl bg-indigo-900">
              <div className="flex h-28 w-28 -mb-14 items-center justify-center rounded-full border-4 border-white bg-amber-500 text-4xl font-bold text-indigo-950 shadow-lg">
                DA
              </div>
            </div>
            <div className="px-8 pb-10 pt-16 text-center">
              <h2 className="text-2xl font-bold text-indigo-950">
                Rev Mrs Deborah Adebowale
              </h2>
              <p className="mt-1 font-medium text-amber-600">Co-Pastor</p>
              <p className="mt-5 text-left leading-relaxed text-slate-600">
                Rev Mrs Deborah Adebowale is a graceful co-pastor and a devoted
                minister with a strong calling to nurture women, children, and
                families in the faith. Her ministry is marked by compassion,
                wisdom, and a deep love for God&apos;s people.
              </p>
              <p className="mt-4 text-left leading-relaxed text-slate-600">
                She leads initiatives that empower women, strengthen marriages,
                and support the next generation. Through her counsel and
                teaching, many have found hope, restoration, and purpose in
                Christ.
              </p>
            </div>
          </article>
        </div>

        <div className="mt-16 rounded-3xl bg-indigo-50 p-8 text-center md:p-12">
          <h2 className="text-2xl font-bold text-indigo-950">
            Support the Ministry
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-slate-600">
            Partner with Apostle Solomon Adebowale and Rev Mrs Deborah Adebowale
            to spread the Gospel and touch lives around the world.
          </p>
          <div className="mt-8">
            <DonateButton />
          </div>
        </div>
      </section>
    </>
  );
}
