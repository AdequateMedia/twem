"use client";

import Link from "next/link";

export function DonateButton({
  href = "https://flutterwave.com/donate/l6hwq0gpjibb",
  children = "Give Online",
  className = "",
}: {
  href?: string;
  children?: React.ReactNode;
  className?: string;
}) {
  return (
    <Link
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`inline-flex items-center justify-center rounded-full bg-amber-500 px-8 py-4 text-base font-bold text-indigo-950 shadow-lg transition hover:-translate-y-0.5 hover:bg-amber-400 ${className}`}
    >
      {children}
      <svg
        className="ml-2 h-5 w-5"
        fill="none"
        stroke="currentColor"
        strokeWidth={2}
        viewBox="0 0 24 24"
      >
        <path
          strokeLinecap="round"
          strokeLinejoin="round"
          d="M17 8l4 4m0 0l-4 4m4-4H3"
        />
      </svg>
    </Link>
  );
}
