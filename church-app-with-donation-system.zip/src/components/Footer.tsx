import Link from "next/link";

export function Footer() {
  return (
    <footer className="bg-indigo-950 py-12 text-indigo-200">
      <div className="mx-auto max-w-6xl px-6">
        <div className="grid gap-10 md:grid-cols-3">
          <div>
            <h3 className="text-lg font-bold text-white">TRUE Worshippers</h3>
            <p className="mt-3 text-sm leading-relaxed">
              Evangelical Assembly International — a family of faith, worship,
              and love committed to raising true worshippers across the nations.
            </p>
          </div>

          <div>
            <h4 className="font-semibold text-white">Quick Links</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li>
                <Link href="/" className="hover:text-white">
                  Home
                </Link>
              </li>
              <li>
                <Link href="/about" className="hover:text-white">
                  About
                </Link>
              </li>
              <li>
                <Link href="/pastors" className="hover:text-white">
                  Our Pastors
                </Link>
              </li>
              <li>
                <Link href="/donate" className="hover:text-white">
                  Donate
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-semibold text-white">Contact</h4>
            <ul className="mt-3 space-y-2 text-sm">
              <li>Email: info@trueworshippers.org</li>
              <li>Phone: +234 000 000 0000</li>
              <li>Location: Nigeria</li>
            </ul>
          </div>
        </div>

        <div className="mt-10 border-t border-white/10 pt-6 text-center text-xs">
          &copy; {new Date().getFullYear()} TRUE Worshippers Evangelical Assembly
          International. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
