import "dotenv/config";
import { eq } from "drizzle-orm";
import bcrypt from "bcryptjs";
import { db } from "./index";
import { users } from "./schema";

async function seed() {
  const adminUsername = process.env.ADMIN_USERNAME ?? "admin";
  const adminPassword = process.env.ADMIN_PASSWORD ?? "Adequate@1";

  const existing = await db
    .select({ id: users.id })
    .from(users)
    .where(eq(users.username, adminUsername))
    .limit(1);

  if (existing.length > 0) {
    console.log(`Admin user "${adminUsername}" already exists.`);
    return;
  }

  const passwordHash = await bcrypt.hash(adminPassword, 12);

  await db.insert(users).values({
    username: adminUsername,
    passwordHash,
    role: "admin",
  });

  console.log(`Created admin user "${adminUsername}".`);
}

seed()
  .catch((error) => {
    console.error("Seed failed:", error);
    process.exit(1);
  })
  .finally(async () => {
    process.exit(0);
  });
