"use server";

import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { users } from "@/db/schema";
import { signSession, verifyPassword } from "./auth";

export async function login(
  _prevState: unknown,
  formData: FormData
): Promise<{ error: string } | null> {
  const username = String(formData.get("username") ?? "").trim();
  const password = String(formData.get("password") ?? "");

  if (!username || !password) {
    return { error: "Username and password are required." };
  }

  const rows = await db
    .select({ id: users.id, username: users.username, passwordHash: users.passwordHash, role: users.role })
    .from(users)
    .where(eq(users.username, username))
    .limit(1);

  const user = rows[0];

  if (!user || !(await verifyPassword(password, user.passwordHash))) {
    return { error: "Invalid username or password." };
  }

  const token = await signSession({ username: user.username, role: user.role });
  const cookieStore = await cookies();

  cookieStore.set("session", token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 8, // 8 hours
  });

  redirect("/admin/dashboard");
}

export async function logout() {
  const cookieStore = await cookies();
  cookieStore.delete("session");
  redirect("/admin/login");
}
