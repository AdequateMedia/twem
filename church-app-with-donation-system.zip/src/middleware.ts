import { NextResponse, type NextRequest } from "next/server";
import { verifySession } from "./lib/auth";

export const config = {
  matcher: ["/admin/dashboard", "/admin/dashboard/:path*"],
};

export async function middleware(request: NextRequest) {
  const token = request.cookies.get("session")?.value;

  if (!token) {
    return NextResponse.redirect(new URL("/admin/login", request.url));
  }

  try {
    await verifySession(token);
    return NextResponse.next();
  } catch {
    const response = NextResponse.redirect(new URL("/admin/login", request.url));
    response.cookies.delete("session");
    return response;
  }
}
